﻿namespace ADO_Practice.Controllers
{
    internal class NorthwindEntities
    {
    }
}